
export interface SlideProps {
  isActive: boolean;
}

export interface TeamMember {
  name: string;
  title: string;
  background: string;
  imageUrl: string;
}
